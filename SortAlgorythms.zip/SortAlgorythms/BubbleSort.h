#pragma once

class BubbleSort
{
public:
	static void sort(int a[], int arraySize);
private:
	static void printRun(int a[], int run, int arraySize);
};