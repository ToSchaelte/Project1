﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp20240828
{
    public static class Enums
    {
        public enum Experience
        {
            LessThanOne,
            OneToFour,
            FiveToNine,
            MoreThanTen
        }
    }
}
